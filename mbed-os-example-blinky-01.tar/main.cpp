#include "stm32wlxx.h"

int main(void) {
  // Enable GPIO D clock
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  
  // Configure GPIO D pin 12 as output
  GPIOA->MODER &= ~(GPIO_MODER_MODE12_Msk);
  GPIOA->MODER |= GPIO_MODER_MODE12_0;
  
  while(1) {
    // Toggle GPIO D pin 12
    GPIOA->ODR ^= GPIO_ODR_OD12;
    for(int i = 0; i < 1000000; i++); // Delay
  }
}